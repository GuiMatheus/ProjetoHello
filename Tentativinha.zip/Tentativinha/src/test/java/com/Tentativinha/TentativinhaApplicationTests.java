package com.Tentativinha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TentativinhaApplicationTests {

	@Test
	void contextLoads() {
	}

}
